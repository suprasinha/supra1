export class Student {
    id: number;
    name: string;
    salary: number;
    des: string;
    addr: string;
}
